
let abajo=false;
let ventana;
let intervalo;  
        function crearVentana() {
            ventana = window.open("","", "width=500,height=200");
            abajo=false;   
            intervalo = setInterval(moverVentana, 100);       
        }

        function moverVentana() {
            if(abajo===false)ventana.moveBy(19.5,10);
            if(ventana.screenY>=759)abajo=true;
            if(abajo===true)ventana.moveBy(-19.5,-10)
            if(ventana.screenY==0) abajo=false;     
        }

        function pararVentana() {
            clearInterval(intervalo); 
        }

        function borrarVentana() {
            pararVentana();
            ventana.close(); 
            }
        