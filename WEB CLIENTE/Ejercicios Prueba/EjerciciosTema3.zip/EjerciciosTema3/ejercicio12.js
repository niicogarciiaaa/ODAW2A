let ventanaEmergente = null; // Inicializa la variable como null

function abrirVentanaEmergente() {
    
    ventanaEmergente = window.open("", "Ventana Emergente", "width=400,height=200");
    
    
    if (ventanaEmergente) {
        
        ventanaEmergente.document.write("Hola, ventana abierta correctamente");

       
        setTimeout(cerrarVentanaEmergente, 3000);
    } 
       
    
}

function cerrarVentanaEmergente() {
    if (ventanaEmergente && !ventanaEmergente.closed) {
        ventanaEmergente.close(); 
    }
}