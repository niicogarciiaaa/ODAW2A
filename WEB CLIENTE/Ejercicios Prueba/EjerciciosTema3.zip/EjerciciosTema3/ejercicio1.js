let diaHoy = Date.now();

let finCurso = new Date(2025, 5, 22)// Junio es el mes 5

const MILISEGUNDOSDIA = (1000 * 60 * 60 * 24);

let diasRestantes =Math.ceil((finCurso-diaHoy) / MILISEGUNDOSDIA);

document.getElementById("resultado").innerHTML = `${diasRestantes} días restantes hasta el fin de curso.`;
