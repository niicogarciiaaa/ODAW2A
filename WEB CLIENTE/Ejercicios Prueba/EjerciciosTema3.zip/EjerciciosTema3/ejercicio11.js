navigator.geolocation.getCurrentPosition(mostrarCoordenadas);


function mostrarCoordenadas(posicion) {
    console.log("Latitud: " + posicion.coords.latitude);
    console.log("Longitud: " + posicion.coords.longitude);
}

