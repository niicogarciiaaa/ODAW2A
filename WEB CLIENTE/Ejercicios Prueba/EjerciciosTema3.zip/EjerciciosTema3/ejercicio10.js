 
 function redirigirError() {
    
    const confirmar = confirm("Ocurrió un error. ¿Quieres ir a la pagina de error?");

    
    if (!confirmar) {
        
        window.location.href = "pagina_error.html"; // Cambia a la URL de tu página de error
    } 
}
