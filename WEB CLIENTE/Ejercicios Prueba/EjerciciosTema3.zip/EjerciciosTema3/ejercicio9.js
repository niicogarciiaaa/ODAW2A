function calcularLetraControl() {
    const input = document.getElementById("numero").value.toUpperCase();
    let numero;

    // Validar NIF
    if (/^\d{8}$/.test(input)) { // El test, lo que hace es devolver un booleano que dice si encuentra en el patron
        numero = input;
    }
    // Validar NIE
    else if (/^[XYZ]\d{7}$/.test(input)) {
        numero = input.replace(/^X/, '0').replace(/^Y/, '1').replace(/^Z/, '2');
    } else {
        alert("Introduce un NIF o NIE válido");
        return;
    }

 
    const tablaLetras = "TRWAGMYFPDXBNJZSQVHLCKE";
    const resto = numero % 23;
    const letraControl = tablaLetras.charAt(resto);


    document.getElementById("letraControl").value = letraControl;
}

