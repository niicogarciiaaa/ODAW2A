function ComprobarOrdenador(){
    let nombre=document.getElementById("nombre").value; //Obtenemos lo que se pasa por html
    if(nombre.substring(0,3)=="DOC" && (nombre.charAt(nombre.length-1)=="A"
    || nombre.charAt(nombre.length-1)=="B"||nombre.charAt(nombre.length-1)=="C")){ 
        let numero=parseInt(nombre.substring(3,nombre.length-1));  //la posicion del numero es desde la 3 hasta la penultima
        if (numero<=252 && numero>=0)
            document.getElementById("resultado").innerHTML=comprobadorLetra(nombre)+numero; 
        else ocument.getElementById("resultado").innerHTML="Nombre introducido no válido";
    }
    else if(nombre.substring(0,4)=="025P" && (nombre.charAt(nombre.length-1)=="A" 
         || nombre.charAt(nombre.length-1)=="B" ||nombre.charAt(nombre.length-1)=="C") ){
        let numero=parseInt(nombre.substring(4,nombre.length-1));
        if (numero<=252 && numero>=0)
            document.getElementById("resultado").innerHTML=comprobadorLetra(nombre)+numero;
        else ocument.getElementById("resultado").innerHTML="Nombre introducido no válido";
    }
}


function comprobadorLetra(nombre){
    switch(true){
        case (nombre.charAt(nombre.length-1)=="A"):
            return "10.42.68.";
            break;
        case (nombre.charAt(nombre.length-1)=="B"):
            return "10.42.69.";
            break;
        case (nombre.charAt(nombre.length-1)=="C"):
            return "10.52.178.";
            break;


    }


   
}
