let i=7;
document.write("Tabla de Multiplicar del 7")
for(let j=1;j<=10;j++){
    document.write(i+"x"+j+"="+i*j+"<br/>")
}
