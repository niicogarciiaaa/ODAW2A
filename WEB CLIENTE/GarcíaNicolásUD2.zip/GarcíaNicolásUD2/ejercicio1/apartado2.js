let i=8;
let j=1;

while(j<=10){
    document.write(i+"+"+j+"="+(i+j)+"<br/>")
    j++
}