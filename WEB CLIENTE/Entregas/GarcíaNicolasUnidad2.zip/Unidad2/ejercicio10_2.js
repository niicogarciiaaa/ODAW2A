let jugadora = prompt("Introduce la jugadora para saber si fue convocada:");
switch(jugadora){
    case "Luisa":
        document.write("Jugadora convocada");
        
    case "Maria":
        document.write("Jugadora convocada");
        
    case "Carlota":
        document.write("Jugadora convocada");
        
    case "Ana":
        document.write("Jugadora convocada");
        
    case "Claudia":
        document.write("Jugadora convocada");
        
    default:
        document.write("No convocada");
}