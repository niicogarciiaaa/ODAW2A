let jugadora = prompt("Introduce la jugadora para saber si fue convocada:");

if(jugadora=="Luisa"||jugadora=="Maria"|| jugadora=="Carlota"||jugadora=="Ana"||jugadora=="Martina"||jugadora=="Claudia"){
    alert("Jugadora convocada")
}else{
    alert("Jugadora NO convocada")
}

