let entero=1357;
let decimal=135.7;
let hexadecimal=0x1357;
let cientifico=135e7;
let octal=0o1357;




//mostrar por consola
console.log("Número entero " + entero);
console.log("Número decimal " + decimal);
console.log("Número hexadecimal " + entero);
console.log("Número científico " + cientifico);
console.log("Número octal " + octal);