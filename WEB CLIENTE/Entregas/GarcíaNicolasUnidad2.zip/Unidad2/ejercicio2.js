
let frase="'Hola como estás?'"
let nombre="Nicolás"
let apellido="García"
let fechaNac=2005
let edad=19

alert(frase)
alert("Nombre: "+nombre+"\n"+"Apellido: "+apellido)
alert("La suma es:"+(fechaNac+edad))
alert(frase+nombre+apellido+fechaNac+edad)
