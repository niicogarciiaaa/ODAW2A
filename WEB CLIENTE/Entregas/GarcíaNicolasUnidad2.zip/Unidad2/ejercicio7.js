let respuesta = prompt("Cual fue el apellido del primer presidente de la democracia española ")
while(respuesta !="Suarez"){
    window.alert("Incorrecto")
     respuesta = prompt("Cual fue el apellido del primer presidente de la democracia española ")
}
document.write("Correcto,Tienes acceso a la página")

