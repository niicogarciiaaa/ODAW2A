// Creación de la clase Jugador
class Jugador {
    
    constructor() {
        this.fuerza = 1;
    }
    incrementarFuerza() {
        this.fuerza+=1;
       
    }
    consultarFuerza(){
        return this.fuerza;

    }
}

let jugador1 = new Jugador();


function consultar(){
    document.getElementById("resultado").innerHTML=jugador1.consultarFuerza();
}







